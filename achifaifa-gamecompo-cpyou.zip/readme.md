###CPYou

Assembly language inspired puzzle game

[Play here](http://achi.se/projects/software/games/cpyou/)
